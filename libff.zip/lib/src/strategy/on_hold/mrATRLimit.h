#pragma once

#include <cmath>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "data_types.h"
#include "indicator_engine.h"
#include "indicator_spec.h"
#include "logger.h"
#include "market_filter.h"
#include "ranker.h"
#include "strategy.h"
#include "universe_selector.h"


/**************************************************************************************
 * Type    : StrategyMRATRLimit
 * Purpose : Long mean-reversion strategy using ATR-based limit entries
 *
 * RealTest equivalent:
 *
 *   Strategy: MR_ATRLimit
 *   Side: Long
 *   QtyType: Percent
 *   Quantity: QtyPct
 *   SetupScore: ROC(C, MOMn)
 *   MaxPositions: MaxPos
 *
 *   EntrySetup:
 *       CanTrade
 *       Extern($BTCUSDT, C > MA(C, BTCMALen))
 *
 *   EntryLimit:
 *       C - ATRm * ATR(AtrL)
 *
 *   ExitRule:
 *       BarsHeld == BarsH
 *
 * Notes:
 *   - Limit order is valid only for the next bar.
 *   - If next bar does not touch the limit, no trade is opened.
 *   - If next bar opens below the limit, entry fills at next open.
 **************************************************************************************/
class StrategyMRATRLimit final : public Strategy {
public:
    StrategyMRATRLimit(
        unsigned int maxPosOpen,
        double qtyFraction,
        std::unique_ptr<UniverseSelector> universeSelector,
        std::unique_ptr<Ranker> ranker,
        double commissionEntryFactor,
        double commissionExitFactor,
        unsigned int maxRankingPosition,
        unsigned int atrLength,
        double atrMultiple,
        unsigned int heldBars,
        unsigned int btcMALength,
        Coin benchmarkCoin = "BTC",
        std::vector<std::unique_ptr<MarketFilter>> marketFilters = {}
    )
        : Strategy(
              "MR_ATRLimit",
              maxPosOpen,
              qtyFraction,
              std::move(universeSelector),
              std::move(ranker),
              commissionEntryFactor,
              commissionExitFactor,
              maxRankingPosition,
              std::move(marketFilters)
          ),
          atrMultiple_(atrMultiple),
          heldBars_(heldBars),
          benchmarkCoin_(std::move(benchmarkCoin)),
          atrSpec_{IndicatorKind::ATR, PriceField::Close, atrLength},
          btcMASpec_{IndicatorKind::SMA, PriceField::Close, btcMALength}
    {}

    std::vector<IndicatorSpec> requiredIndicators() const override
    {
        std::vector<IndicatorSpec> specs = Strategy::requiredIndicators();

        specs.push_back(atrSpec_);
        specs.push_back(btcMASpec_);

        return specs;
    }

protected:
    bool shouldEnter(
        const Coin& coin,
        const MarketData& marketData,
        Timestamp ts,
        const std::vector<Trade>&,
        double,
        const IndicatorEngine& indicators
    ) const override
    {
        const BarData* bar = findBar(marketData, coin, ts);
        const double atr = indicators.value(coin, ts, atrSpec_);

        return
            bar &&
            bar->close > 0.0 &&
            std::isfinite(atr) &&
            atr > 0.0 &&
            btcAboveMA(marketData, ts, indicators);
    }

    Trade buildTrade(
        const Coin& coin,
        const MarketData& marketData,
        Timestamp ts,
        unsigned int& last_trade_id,
        double strategy_allocation,
        bool live_trading,
        const IndicatorEngine& indicators
    ) const override
    {
        (void)live_trading;

        const BarData* setupBar = findBar(marketData, coin, ts);

        if (!setupBar) {
            return invalidTrade();
        }

        const double atr = indicators.value(coin, ts, atrSpec_);

        if (!std::isfinite(atr) || atr <= 0.0 || setupBar->close <= 0.0) {
            return invalidTrade();
        }

        const double limitPrice =
            setupBar->close - atrMultiple_ * atr;

        if (limitPrice <= 0.0) {
            return invalidTrade();
        }

        Timestamp entryTs = 0;
        BarData entryBar;

        if (!findNextBar(marketData, coin, ts, entryTs, entryBar)) {
            LG_ERROR(
                "Could not find next day for coin {} and date {} when building the limit trade",
                coin,
                ts
            );

            return invalidTrade();
        }

        if (entryBar.low > limitPrice) {
            return invalidTrade();
        }

        const double entryPrice =
            entryBar.open > 0.0 && entryBar.open <= limitPrice
                ? entryBar.open
                : limitPrice;

        if (entryPrice <= 0.0) {
            return invalidTrade();
        }

        const double tradeValue = strategy_allocation * riskPerTrade_;
        const double size = tradeValue / entryPrice;

        Trade trade;

        trade.trade_id_ = ++last_trade_id;
        trade.start_ = entryTs;
        trade.end_ = 0;

        trade.coin_ = coin;
        trade.direction_ = Direction::Long;

        trade.entry_ = entryPrice;
        trade.exit_ = 0.0;
        trade.current_price_ = entryPrice;

        trade.size_ = size;
        trade.pnl_ = 0.0;

        trade.commission_ =
            entryPrice * size * commissionEntryFactor_;

        trade.sl_ = 0.0;
        trade.slReference_ = 0.0;

        trade.isSimulated_ = false;
        trade.exited_ = false;
        trade.barsHeld = 0;

        trade.strategy_name_ = strategy_name_;

        return trade;
    }

    void onBar(
        Trade& trade,
        const Coin& coin,
        const MarketData& marketData,
        Timestamp ts,
        bool live_trading,
        const IndicatorEngine&
    ) const override
    {
        (void)live_trading;

        const BarData* bar = findBar(marketData, coin, ts);

        if (!bar || ts < trade.start_) {
            return;
        }

        trade.current_price_ = bar->close;
        trade.pnl_ = (trade.current_price_ - trade.entry_) * trade.size_;

        ++trade.barsHeld;

        if (trade.barsHeld < heldBars_) {
            return;
        }

        Timestamp exitTs = 0;
        BarData exitBar;

        if (findNextBar(marketData, coin, ts, exitTs, exitBar)) {
            trade.exit_ = exitBar.open > 0.0
                ? exitBar.open
                : exitBar.close;

            trade.end_ = exitTs;
        } else {
            LG_ERROR(
                "Could not find next day for coin {} and date {} when exiting the trade, using close instead of next open",
                coin,
                ts
            );

            trade.exit_ = bar->close;
            trade.end_ = ts;
        }

        trade.exited_ = true;

        trade.pnl_ = (trade.exit_ - trade.entry_) * trade.size_;

        trade.commission_ +=
            trade.exit_ * trade.size_ * commissionExitFactor_;
    }

private:
    bool btcAboveMA(
        const MarketData& marketData,
        Timestamp ts,
        const IndicatorEngine& indicators
    ) const
    {
        const BarData* btcBar = findBar(marketData, benchmarkCoin_, ts);
        const double btcMA = indicators.value(benchmarkCoin_, ts, btcMASpec_);

        return
            btcBar &&
            std::isfinite(btcMA) &&
            btcMA > 0.0 &&
            btcBar->close > btcMA;
    }

    const BarData* findBar(
        const MarketData& marketData,
        const Coin& coin,
        Timestamp ts
    ) const
    {
        const auto tsIt = marketData.find(ts);

        if (tsIt == marketData.end()) {
            return nullptr;
        }

        const auto coinIt = tsIt->second.find(coin);

        if (coinIt == tsIt->second.end()) {
            return nullptr;
        }

        return &coinIt->second;
    }

    bool findNextBar(
        const MarketData& marketData,
        const Coin& coin,
        Timestamp ts,
        Timestamp& nextTs,
        BarData& nextBar
    ) const
    {
        auto it = marketData.upper_bound(ts);

        while (it != marketData.end()) {
            const auto coinIt = it->second.find(coin);

            if (coinIt != it->second.end()) {
                nextTs = it->first;
                nextBar = coinIt->second;
                return true;
            }

            ++it;
        }

        return false;
    }

    Trade invalidTrade() const
    {
        Trade trade;

        trade.strategy_name_ = strategy_name_;
        trade.isSimulated_ = true;
        trade.exited_ = true;

        return trade;
    }

private:
    double atrMultiple_ = 0.0;
    unsigned int heldBars_ = 0;

    Coin benchmarkCoin_;

    IndicatorSpec atrSpec_;
    IndicatorSpec btcMASpec_;
};