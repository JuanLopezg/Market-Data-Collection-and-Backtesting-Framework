#pragma once

#include <algorithm>
#include <cmath>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "data_types.h"
#include "indicator_engine.h"
#include "indicator_spec.h"
#include "logger.h"
#include "market_filter.h"
#include "ranker.h"
#include "strategy.h"
#include "universe_selector.h"


/**************************************************************************************
 * Type    : StrategyMRLowsSweeper
 * Purpose : Buy short-term lows during positive BTC regime
 *
 * RealTest equivalent:
 *
 *   Strategy: MR_LowsSweeper
 *   Side: Long
 *   QtyType: Percent
 *   Quantity: QtyPct
 *   SetupScore: ROC(C, rocN)
 *   MaxPositions: MaxPos
 *   EntrySetup:
 *       CanTrade
 *       Extern($BTCUSDT, C > MA(C, BTCMALen))
 *   EntryLimit:
 *       Lowest(L, xL)
 *   ExitRule:
 *       BarsHeld == HeldBars
 *
 * Notes:
 *   - EntryLimit is treated as a one-bar buy limit order.
 *   - If the next bar does not touch the limit, no trade is opened.
 **************************************************************************************/
class StrategyMRLowsSweeper final : public Strategy {
public:
    StrategyMRLowsSweeper(
        unsigned int maxPosOpen,
        double qtyFraction,
        std::unique_ptr<UniverseSelector> universeSelector,
        std::unique_ptr<Ranker> ranker,
        double commissionEntryFactor,
        double commissionExitFactor,
        unsigned int maxRankingPosition,
        unsigned int heldBars,
        unsigned int xL,
        unsigned int btcMALen,
        std::string benchmarkCoin = "BTC",
        std::vector<std::unique_ptr<MarketFilter>> marketFilters = {}
    )
        : Strategy(
              "MR_LowsSweeper",
              maxPosOpen,
              qtyFraction,
              std::move(universeSelector),
              std::move(ranker),
              commissionEntryFactor,
              commissionExitFactor,
              maxRankingPosition,
              std::move(marketFilters)
          ),
          heldBars_(std::max(heldBars, 1u)),
          benchmarkCoin_(std::move(benchmarkCoin)),
          entryLimitSpec_{IndicatorKind::Lowest, PriceField::Low, xL},
          btcMASpec_{IndicatorKind::SMA, PriceField::Close, btcMALen}
    {}

    std::vector<IndicatorSpec> requiredIndicators() const override
    {
        std::vector<IndicatorSpec> specs = Strategy::requiredIndicators();

        specs.push_back(entryLimitSpec_);
        specs.push_back(btcMASpec_);

        return specs;
    }

protected:
    bool shouldEnter(
        const Coin& coin,
        const MarketData& marketData,
        Timestamp ts,
        const std::vector<Trade>&,
        double,
        const IndicatorEngine& indicators
    ) const override
    {
        const BarData* btcBar = findBar(marketData, benchmarkCoin_, ts);

        if (!btcBar) {
            return false;
        }

        const double btcMA = indicators.value(benchmarkCoin_, ts, btcMASpec_);
        const double entryLimit = indicators.value(coin, ts, entryLimitSpec_);

        if (!std::isfinite(btcMA) ||
            !std::isfinite(entryLimit) ||
            btcMA <= 0.0 ||
            entryLimit <= 0.0) {
            return false;
        }

        if (btcBar->close <= btcMA) {
            return false;
        }

        Timestamp entryTs = 0;
        BarData entryBar;

        if (!findFutureBar(marketData, coin, ts, 1, entryTs, entryBar)) {
            return false;
        }

        return entryBar.low <= entryLimit;
    }

    Trade buildTrade(
        const Coin& coin,
        const MarketData& marketData,
        Timestamp ts,
        unsigned int& last_trade_id,
        double strategy_allocation,
        bool live_trading,
        const IndicatorEngine& indicators
    ) const override
    {
        (void)live_trading;

        const double entryLimit = indicators.value(coin, ts, entryLimitSpec_);

        if (!std::isfinite(entryLimit) || entryLimit <= 0.0) {
            return invalidTrade();
        }

        Timestamp entryTs = 0;
        BarData entryBar;

        if (!findFutureBar(marketData, coin, ts, 1, entryTs, entryBar)) {
            return invalidTrade();
        }

        if (entryBar.low > entryLimit) {
            return invalidTrade();
        }

        /*
         * Buy limit execution:
         * - If next bar opens below the limit, fill at open.
         * - Otherwise fill at the limit price.
         */
        const double entryPrice =
            std::min(entryLimit, entryBar.open);

        if (entryPrice <= 0.0) {
            return invalidTrade();
        }

        const double tradeValue =
            strategy_allocation * riskPerTrade_;

        const double size =
            tradeValue / entryPrice;

        Trade trade;

        trade.trade_id_ = ++last_trade_id;
        trade.start_ = entryTs;
        trade.end_ = 0;

        trade.coin_ = coin;
        trade.direction_ = Direction::Long;

        trade.entry_ = entryPrice;
        trade.exit_ = 0.0;
        trade.current_price_ = entryPrice;

        trade.size_ = size;
        trade.pnl_ = 0.0;

        trade.commission_ =
            entryPrice * size * commissionEntryFactor_;

        trade.sl_ = 0.0;
        trade.slReference_ = 0.0;

        trade.isSimulated_ = false;
        trade.exited_ = false;
        trade.barsHeld = 0;

        trade.strategy_name_ = strategy_name_;

        return trade;
    }

    void onBar(
        Trade& trade,
        const Coin& coin,
        const MarketData& marketData,
        Timestamp ts,
        bool live_trading,
        const IndicatorEngine&
    ) const override
    {
        (void)live_trading;

        const BarData* bar = findBar(marketData, coin, ts);

        if (!bar || ts < trade.start_) {
            return;
        }

        trade.current_price_ = bar->close;
        trade.pnl_ =
            (trade.current_price_ - trade.entry_) * trade.size_;

        ++trade.barsHeld;

        if (trade.barsHeld < heldBars_) {
            return;
        }

        trade.exit_ = bar->close;
        trade.end_ = ts;
        trade.exited_ = true;

        trade.pnl_ =
            (trade.exit_ - trade.entry_) * trade.size_;

        trade.commission_ +=
            trade.exit_ * trade.size_ * commissionExitFactor_;
    }

private:
    const BarData* findBar(
        const MarketData& marketData,
        const Coin& coin,
        Timestamp ts
    ) const
    {
        const auto tsIt = marketData.find(ts);

        if (tsIt == marketData.end()) {
            return nullptr;
        }

        const auto coinIt = tsIt->second.find(coin);

        if (coinIt == tsIt->second.end()) {
            return nullptr;
        }

        return &coinIt->second;
    }

    bool findFutureBar(
        const MarketData& marketData,
        const Coin& coin,
        Timestamp ts,
        unsigned int barsAhead,
        Timestamp& futureTs,
        BarData& futureBar
    ) const
    {
        auto it = marketData.upper_bound(ts);

        for (unsigned int i = 1; i <= barsAhead; ++i) {
            if (it == marketData.end()) {
                return false;
            }

            const auto coinIt = it->second.find(coin);

            if (coinIt == it->second.end()) {
                return false;
            }

            if (i == barsAhead) {
                futureTs = it->first;
                futureBar = coinIt->second;
                return true;
            }

            ++it;
        }

        return false;
    }

    Trade invalidTrade() const
    {
        Trade trade;

        trade.strategy_name_ = strategy_name_;
        trade.isSimulated_ = true;
        trade.exited_ = true;

        return trade;
    }

private:
    unsigned int heldBars_ = 15;

    std::string benchmarkCoin_ = "BTC";

    IndicatorSpec entryLimitSpec_;
    IndicatorSpec btcMASpec_;
};