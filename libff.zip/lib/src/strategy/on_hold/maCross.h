#pragma once

#include <cmath>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "data_types.h"
#include "indicator_engine.h"
#include "indicator_spec.h"
#include "logger.h"
#include "market_filter.h"
#include "ranker.h"
#include "strategy.h"
#include "universe_selector.h"


/**************************************************************************************
 * Type    : StrategyMACross
 * Purpose : Long moving-average cross strategy
 *
 * RealTest equivalent:
 *
 *   Strategy: MA_Cross
 *   Side: Long
 *   QtyType: Percent
 *   Quantity: QtyPct
 *   SetupScore: RV
 *   MaxPositions: MaxPos
 *
 *   EntrySetup:
 *       CanTrade
 *       MA(C, mas) > MA(C, mal)
 *       Extern($BTCUSDT, C > MA(C, BTCMALen))
 *
 *   ExitRule:
 *       MA(C, mas) < MA(C, mal)
 *
 * Notes:
 *   - BTC regime filter should be passed as a MarketFilter from main.
 *   - RV ranking should be SMA(Volume, 25), descending.
 *   - Entry is at next bar open after setup signal.
 *   - Exit is at next bar open after exit signal.
 **************************************************************************************/
class StrategyMACross final : public Strategy {
public:
    StrategyMACross(
        unsigned int maxPosOpen,
        double qtyFraction,
        std::unique_ptr<UniverseSelector> universeSelector,
        std::unique_ptr<Ranker> ranker,
        double commissionEntryFactor,
        double commissionExitFactor,
        unsigned int maxRankingPosition,
        unsigned int shortMALength,
        unsigned int longMALength,
        std::vector<std::unique_ptr<MarketFilter>> marketFilters = {}
    )
        : Strategy(
              "MA_Cross",
              maxPosOpen,
              qtyFraction,
              std::move(universeSelector),
              std::move(ranker),
              commissionEntryFactor,
              commissionExitFactor,
              maxRankingPosition,
              std::move(marketFilters)
          ),
          shortMASpec_{IndicatorKind::SMA, PriceField::Close, shortMALength},
          longMASpec_{IndicatorKind::SMA, PriceField::Close, longMALength}
    {}

    std::vector<IndicatorSpec> requiredIndicators() const override
    {
        std::vector<IndicatorSpec> specs = Strategy::requiredIndicators();

        specs.push_back(shortMASpec_);
        specs.push_back(longMASpec_);

        return specs;
    }

protected:
    bool shouldEnter(
        const Coin& coin,
        const MarketData&,
        Timestamp ts,
        const std::vector<Trade>&,
        double,
        const IndicatorEngine& indicators
    ) const override
    {
        const double shortMA = indicators.value(coin, ts, shortMASpec_);
        const double longMA  = indicators.value(coin, ts, longMASpec_);

        return
            std::isfinite(shortMA) &&
            std::isfinite(longMA) &&
            shortMA > longMA;
    }

    Trade buildTrade(
        const Coin& coin,
        const MarketData& marketData,
        Timestamp ts,
        unsigned int& last_trade_id,
        double strategy_allocation,
        bool live_trading,
        const IndicatorEngine&
    ) const override
    {
        (void)live_trading;

        Timestamp entryTs = 0;
        BarData entryBar;

        if (!findNextBar(marketData, coin, ts, entryTs, entryBar)) {
            LG_ERROR(
                "Could not find next day for coin {} and date {} when building the trade, using current close instead",
                coin,
                ts
            );

            const BarData* currentBar = findBar(marketData, coin, ts);

            if (!currentBar) {
                return invalidTrade();
            }

            entryTs = ts;
            entryBar = *currentBar;
        }

        const double entryPrice = entryBar.open > 0.0
            ? entryBar.open
            : entryBar.close;

        if (entryPrice <= 0.0) {
            return invalidTrade();
        }

        const double tradeValue = strategy_allocation * riskPerTrade_;
        const double size = tradeValue / entryPrice;

        Trade trade;

        trade.trade_id_ = ++last_trade_id;
        trade.start_ = entryTs;
        trade.end_ = 0;

        trade.coin_ = coin;
        trade.direction_ = Direction::Long;

        trade.entry_ = entryPrice;
        trade.exit_ = 0.0;
        trade.current_price_ = entryPrice;

        trade.size_ = size;
        trade.pnl_ = 0.0;

        trade.commission_ =
            entryPrice * size * commissionEntryFactor_;

        trade.sl_ = 0.0;
        trade.slReference_ = 0.0;

        trade.isSimulated_ = false;
        trade.exited_ = false;
        trade.barsHeld = 0;

        trade.strategy_name_ = strategy_name_;

        return trade;
    }

    void onBar(
        Trade& trade,
        const Coin& coin,
        const MarketData& marketData,
        Timestamp ts,
        bool live_trading,
        const IndicatorEngine& indicators
    ) const override
    {
        (void)live_trading;

        const BarData* bar = findBar(marketData, coin, ts);

        if (!bar || ts < trade.start_) {
            return;
        }

        trade.current_price_ = bar->close;
        trade.pnl_ = (trade.current_price_ - trade.entry_) * trade.size_;

        ++trade.barsHeld;

        const double shortMA = indicators.value(coin, ts, shortMASpec_);
        const double longMA  = indicators.value(coin, ts, longMASpec_);

        if (
            !std::isfinite(shortMA) ||
            !std::isfinite(longMA) ||
            shortMA >= longMA
        ) {
            return;
        }

        Timestamp exitTs = 0;
        BarData exitBar;

        if (findNextBar(marketData, coin, ts, exitTs, exitBar)) {
            trade.exit_ = exitBar.open > 0.0
                ? exitBar.open
                : exitBar.close;

            trade.end_ = exitTs;
        } else {
            LG_ERROR(
                "Could not find next day for coin {} and date {} when updating the trade, using close instead of next open",
                coin,
                ts
            );

            trade.exit_ = bar->close;
            trade.end_ = ts;
        }

        trade.exited_ = true;

        trade.pnl_ = (trade.exit_ - trade.entry_) * trade.size_;

        trade.commission_ +=
            trade.exit_ * trade.size_ * commissionExitFactor_;
    }

private:
    const BarData* findBar(
        const MarketData& marketData,
        const Coin& coin,
        Timestamp ts
    ) const
    {
        const auto tsIt = marketData.find(ts);

        if (tsIt == marketData.end()) {
            return nullptr;
        }

        const auto coinIt = tsIt->second.find(coin);

        if (coinIt == tsIt->second.end()) {
            return nullptr;
        }

        return &coinIt->second;
    }

    bool findNextBar(
        const MarketData& marketData,
        const Coin& coin,
        Timestamp ts,
        Timestamp& nextTs,
        BarData& nextBar
    ) const
    {
        auto it = marketData.upper_bound(ts);

        while (it != marketData.end()) {
            const auto coinIt = it->second.find(coin);

            if (coinIt != it->second.end()) {
                nextTs = it->first;
                nextBar = coinIt->second;
                return true;
            }

            ++it;
        }

        return false;
    }

    Trade invalidTrade() const
    {
        Trade trade;

        trade.strategy_name_ = strategy_name_;
        trade.isSimulated_ = true;
        trade.exited_ = true;

        return trade;
    }

private:
    IndicatorSpec shortMASpec_;
    IndicatorSpec longMASpec_;
};