#pragma once

// Only strategies migrated to the new SignalState architecture are exported here.
// Legacy breakout/stop strategies remain in the repository but are intentionally not
// included until their signal-trigger migration is implemented.
#include "pureRSI.h"
